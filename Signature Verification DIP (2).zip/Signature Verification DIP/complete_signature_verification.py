"""
Complete Signature Verification System using Digital Image Processing
This is a standalone file with all code in one place - ready for Google Colab
"""

# ============================================================================
# STEP 1: Install Required Libraries (Run this first in Colab)
# ============================================================================
# !pip install opencv-python scikit-image scipy numpy matplotlib

# ============================================================================
# STEP 2: Import Required Libraries
# ============================================================================
import cv2
import numpy as np
import matplotlib.pyplot as plt
from skimage import feature
from scipy.spatial.distance import euclidean
import os

# For Google Colab file uploads
try:
    from google.colab import files
    IN_COLAB = True
except ImportError:
    IN_COLAB = False
    print("Note: Not running in Google Colab. File uploads will need to be handled manually.")


# ============================================================================
# STEP 3: Signature Verifier Class
# ============================================================================
class SignatureVerifier:
    """Main class for signature verification using image processing techniques."""
    
    def __init__(self, reference_signature_path=None):
        """
        Initialize the Signature Verifier.
        
        Args:
            reference_signature_path: Path to the reference signature image
        """
        self.reference_features = None
        if reference_signature_path and os.path.exists(reference_signature_path):
            self.load_reference_signature(reference_signature_path)
    
    def preprocess_image(self, image):
        """
        Preprocess the signature image for feature extraction.
        
        Args:
            image: Input image (numpy array or path)
            
        Returns:
            Preprocessed binary image
        """
        # Load image if path is provided
        if isinstance(image, str):
            img = cv2.imread(image)
        else:
            img = image.copy()
        
        # Convert to grayscale if needed
        if len(img.shape) == 3:
            gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
        else:
            gray = img
        
        # Resize to standard size for comparison
        gray = cv2.resize(gray, (400, 200))
        
        # Apply Gaussian blur to reduce noise
        blurred = cv2.GaussianBlur(gray, (5, 5), 0)
        
        # Adaptive thresholding for better binarization
        binary = cv2.adaptiveThreshold(
            blurred, 255, cv2.ADAPTIVE_THRESH_GAUSSIAN_C,
            cv2.THRESH_BINARY_INV, 11, 2
        )
        
        # Morphological operations to clean up the image
        kernel = np.ones((2, 2), np.uint8)
        binary = cv2.morphologyEx(binary, cv2.MORPH_CLOSE, kernel)
        binary = cv2.morphologyEx(binary, cv2.MORPH_OPEN, kernel)
        
        return binary
    
    def extract_features(self, image):
        """
        Extract features from the signature image.
        
        Args:
            image: Preprocessed binary image
            
        Returns:
            Dictionary containing extracted features
        """
        features = {}
        
        # 1. Aspect Ratio
        height, width = image.shape
        features['aspect_ratio'] = width / height if height > 0 else 0
        
        # 2. Signature Density (percentage of black pixels)
        total_pixels = height * width
        black_pixels = np.sum(image == 255)
        features['density'] = black_pixels / total_pixels if total_pixels > 0 else 0
        
        # 3. Centroid (center of mass)
        moments = cv2.moments(image)
        if moments['m00'] != 0:
            cx = moments['m10'] / moments['m00']
            cy = moments['m01'] / moments['m00']
        else:
            cx, cy = width / 2, height / 2
        features['centroid'] = (cx, cy)
        
        # 4. Bounding Box features
        coords = np.column_stack(np.where(image == 255))
        if len(coords) > 0:
            x_min, y_min = coords.min(axis=0)
            x_max, y_max = coords.max(axis=0)
            bbox_width = x_max - x_min
            bbox_height = y_max - y_min
            features['bbox_ratio'] = bbox_width / bbox_height if bbox_height > 0 else 0
            features['bbox_area_ratio'] = (bbox_width * bbox_height) / total_pixels
        else:
            features['bbox_ratio'] = 0
            features['bbox_area_ratio'] = 0
        
        # 5. Contour features
        contours, _ = cv2.findContours(image, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
        if contours:
            largest_contour = max(contours, key=cv2.contourArea)
            features['contour_area'] = cv2.contourArea(largest_contour)
            features['contour_perimeter'] = cv2.arcLength(largest_contour, True)
            features['num_contours'] = len(contours)
            
            # Convex hull features
            hull = cv2.convexHull(largest_contour)
            hull_area = cv2.contourArea(hull)
            features['solidity'] = features['contour_area'] / hull_area if hull_area > 0 else 0
            
            # Extent (ratio of contour area to bounding box area)
            if bbox_width > 0 and bbox_height > 0:
                bbox_area = bbox_width * bbox_height
                features['extent'] = features['contour_area'] / bbox_area if bbox_area > 0 else 0
            else:
                features['extent'] = 0
        else:
            features['contour_area'] = 0
            features['contour_perimeter'] = 0
            features['num_contours'] = 0
            features['solidity'] = 0
            features['extent'] = 0
        
        # 6. Texture features using Local Binary Pattern (LBP)
        # Convert binary back to grayscale for LBP
        gray_for_lbp = cv2.bitwise_not(image)
        lbp = feature.local_binary_pattern(gray_for_lbp, 8, 1, method='uniform')
        hist, _ = np.histogram(lbp.ravel(), bins=10, range=(0, 10))
        hist = hist.astype(float)
        hist /= (hist.sum() + 1e-7)  # Normalize
        features['lbp_histogram'] = hist
        
        # 7. Hu Moments (invariant moments)
        moments = cv2.moments(image)
        hu_moments = cv2.HuMoments(moments).flatten()
        # Log transform for better scale invariance
        hu_moments = -np.sign(hu_moments) * np.log10(np.abs(hu_moments) + 1e-10)
        features['hu_moments'] = hu_moments
        
        # 8. Horizontal and Vertical Projections
        h_projection = np.sum(image == 255, axis=1)
        v_projection = np.sum(image == 255, axis=0)
        features['h_projection_mean'] = np.mean(h_projection) if len(h_projection) > 0 else 0
        features['v_projection_mean'] = np.mean(v_projection) if len(v_projection) > 0 else 0
        features['h_projection_std'] = np.std(h_projection) if len(h_projection) > 0 else 0
        features['v_projection_std'] = np.std(v_projection) if len(v_projection) > 0 else 0
        
        return features
    
    def calculate_similarity(self, features1, features2):
        """
        Calculate similarity score between two feature sets.
        
        Args:
            features1: First feature dictionary
            features2: Second feature dictionary
            
        Returns:
            Similarity score (0-1, where 1 is most similar)
        """
        similarity_scores = []
        
        # Compare scalar features
        scalar_features = [
            'aspect_ratio', 'density', 'bbox_ratio', 'bbox_area_ratio',
            'contour_area', 'contour_perimeter', 'num_contours',
            'solidity', 'extent', 'h_projection_mean', 'v_projection_mean',
            'h_projection_std', 'v_projection_std'
        ]
        
        for feat_name in scalar_features:
            val1 = features1.get(feat_name, 0)
            val2 = features2.get(feat_name, 0)
            
            if val1 == 0 and val2 == 0:
                similarity_scores.append(1.0)
            elif val1 == 0 or val2 == 0:
                similarity_scores.append(0.0)
            else:
                # Normalized difference
                diff = abs(val1 - val2) / (max(abs(val1), abs(val2)) + 1e-10)
                similarity_scores.append(1.0 - min(diff, 1.0))
        
        # Compare centroid (with normalization)
        centroid1 = features1.get('centroid', (0, 0))
        centroid2 = features2.get('centroid', (0, 0))
        centroid_dist = euclidean(centroid1, centroid2)
        max_dist = np.sqrt(400**2 + 200**2)  # Max distance in 400x200 image
        centroid_sim = 1.0 - min(centroid_dist / max_dist, 1.0)
        similarity_scores.append(centroid_sim)
        
        # Compare LBP histograms
        lbp1 = features1.get('lbp_histogram', np.zeros(10))
        lbp2 = features2.get('lbp_histogram', np.zeros(10))
        lbp_sim = 1.0 - euclidean(lbp1, lbp2) / np.sqrt(2)  # Normalize
        similarity_scores.append(max(0, min(1, lbp_sim)))
        
        # Compare Hu Moments
        hu1 = features1.get('hu_moments', np.zeros(7))
        hu2 = features2.get('hu_moments', np.zeros(7))
        hu_sim = 1.0 - euclidean(hu1, hu2) / (np.linalg.norm(hu1) + np.linalg.norm(hu2) + 1e-10)
        similarity_scores.append(max(0, min(1, hu_sim)))
        
        # Weighted average (geometric features are more important)
        weights = [1.0] * len(scalar_features) + [1.5, 1.2, 1.3]  # Weights for scalar, centroid, lbp, hu
        weighted_sum = sum(s * w for s, w in zip(similarity_scores, weights))
        total_weight = sum(weights)
        
        return weighted_sum / total_weight if total_weight > 0 else 0.0
    
    def load_reference_signature(self, image_path):
        """
        Load and process reference signature.
        
        Args:
            image_path: Path to reference signature image
        """
        preprocessed = self.preprocess_image(image_path)
        self.reference_features = self.extract_features(preprocessed)
        return self.reference_features
    
    def verify_signature(self, test_image, threshold=0.75):
        """
        Verify if a test signature matches the reference signature.
        
        Args:
            test_image: Test signature image (numpy array or path)
            threshold: Similarity threshold (default: 0.75)
            
        Returns:
            Dictionary with verification results
        """
        if self.reference_features is None:
            raise ValueError("Reference signature not loaded. Please load a reference signature first.")
        
        # Preprocess and extract features from test image
        preprocessed = self.preprocess_image(test_image)
        test_features = self.extract_features(preprocessed)
        
        # Calculate similarity
        similarity_score = self.calculate_similarity(self.reference_features, test_features)
        
        # Determine if signature is genuine or fake
        is_genuine = similarity_score >= threshold
        
        result = {
            'is_genuine': is_genuine,
            'similarity_score': similarity_score,
            'threshold': threshold,
            'confidence': 'High' if similarity_score > 0.85 else 'Medium' if similarity_score > 0.70 else 'Low'
        }
        
        return result
    
    def compare_signatures(self, image1_path, image2_path, threshold=0.75):
        """
        Compare two signatures directly.
        
        Args:
            image1_path: Path to first signature image
            image2_path: Path to second signature image
            threshold: Similarity threshold
            
        Returns:
            Dictionary with comparison results
        """
        # Process both images
        preprocessed1 = self.preprocess_image(image1_path)
        preprocessed2 = self.preprocess_image(image2_path)
        
        features1 = self.extract_features(preprocessed1)
        features2 = self.extract_features(preprocessed2)
        
        # Calculate similarity
        similarity_score = self.calculate_similarity(features1, features2)
        is_match = similarity_score >= threshold
        
        result = {
            'is_match': is_match,
            'similarity_score': similarity_score,
            'threshold': threshold,
            'confidence': 'High' if similarity_score > 0.85 else 'Medium' if similarity_score > 0.70 else 'Low'
        }
        
        return result


# ============================================================================
# STEP 4: Main Execution Code for Google Colab
# ============================================================================
def main():
    """Main function to run signature verification in Google Colab."""
    
    print("="*70)
    print("SIGNATURE VERIFICATION SYSTEM")
    print("Using Digital Image Processing")
    print("="*70)
    
    # Step 1: Upload Reference Signature
    print("\n" + "-"*70)
    print("STEP 1: Upload Reference Signature")
    print("-"*70)
    
    if IN_COLAB:
        print("Please upload your reference (genuine) signature image:")
        uploaded_ref = files.upload()
        ref_filename = list(uploaded_ref.keys())[0]
        print(f"\n✓ Reference signature loaded: {ref_filename}")
    else:
        ref_filename = input("Enter path to reference signature image: ").strip()
        if not os.path.exists(ref_filename):
            print(f"Error: File not found - {ref_filename}")
            return
    
    # Initialize verifier with reference signature
    verifier = SignatureVerifier(ref_filename)
    
    # Display the reference signature
    ref_img = cv2.imread(ref_filename)
    if ref_img is None:
        print(f"Error: Could not load image from {ref_filename}")
        return
    
    ref_img_rgb = cv2.cvtColor(ref_img, cv2.COLOR_BGR2RGB)
    plt.figure(figsize=(8, 4))
    plt.imshow(ref_img_rgb)
    plt.title("Reference Signature", fontsize=14, fontweight='bold')
    plt.axis('off')
    plt.show()
    
    print("\n✓ Reference signature loaded successfully!")
    
    # Step 2: Upload Test Signature
    print("\n" + "-"*70)
    print("STEP 2: Upload Test Signature")
    print("-"*70)
    
    if IN_COLAB:
        print("Please upload the signature image to verify:")
        uploaded_test = files.upload()
        test_filename = list(uploaded_test.keys())[0]
        print(f"\n✓ Test signature loaded: {test_filename}")
    else:
        test_filename = input("Enter path to test signature image: ").strip()
        if not os.path.exists(test_filename):
            print(f"Error: File not found - {test_filename}")
            return
    
    # Verify the signature
    threshold = 0.75  # You can adjust this threshold (0.0 to 1.0)
    result = verifier.verify_signature(test_filename, threshold=threshold)
    
    # Display both images side by side
    test_img = cv2.imread(test_filename)
    if test_img is None:
        print(f"Error: Could not load image from {test_filename}")
        return
    
    test_img_rgb = cv2.cvtColor(test_img, cv2.COLOR_BGR2RGB)
    
    fig, axes = plt.subplots(1, 2, figsize=(16, 6))
    
    axes[0].imshow(ref_img_rgb)
    axes[0].set_title("Reference Signature", fontsize=14, fontweight='bold')
    axes[0].axis('off')
    
    axes[1].imshow(test_img_rgb)
    axes[1].set_title("Test Signature", fontsize=14, fontweight='bold')
    axes[1].axis('off')
    
    plt.tight_layout()
    plt.show()
    
    # Display results
    print("\n" + "="*70)
    print("VERIFICATION RESULTS")
    print("="*70)
    print(f"Similarity Score: {result['similarity_score']:.4f} ({result['similarity_score']*100:.2f}%)")
    print(f"Threshold: {result['threshold']:.2f}")
    print(f"Confidence: {result['confidence']}")
    print(f"\n{'✓ GENUINE SIGNATURE' if result['is_genuine'] else '✗ FAKE SIGNATURE'}")
    print("="*70)
    
    # Visualize similarity score
    plt.figure(figsize=(10, 2))
    colors = ['green' if result['is_genuine'] else 'red', 'lightgray']
    plt.barh(['Similarity'], [result['similarity_score'] * 100], color=colors[0], alpha=0.7)
    plt.barh(['Similarity'], [(1 - result['similarity_score']) * 100], 
             left=[result['similarity_score'] * 100], color=colors[1], alpha=0.3)
    plt.xlim(0, 100)
    plt.xlabel('Percentage (%)')
    plt.title(f"Similarity Score: {result['similarity_score']*100:.2f}%")
    plt.axvline(x=threshold*100, color='orange', linestyle='--', linewidth=2, 
                label=f'Threshold ({threshold*100}%)')
    plt.legend()
    plt.grid(axis='x', alpha=0.3)
    plt.tight_layout()
    plt.show()
    
    # Optional: Visualize preprocessing steps
    print("\n" + "-"*70)
    print("OPTIONAL: Preprocessing Visualization")
    print("-"*70)
    show_preprocessing = input("Show preprocessing steps? (y/n): ").strip().lower()
    
    if show_preprocessing == 'y':
        ref_preprocessed = verifier.preprocess_image(ref_filename)
        test_preprocessed = verifier.preprocess_image(test_filename)
        
        fig, axes = plt.subplots(2, 3, figsize=(18, 12))
        
        # Reference signature processing
        ref_original = cv2.imread(ref_filename)
        ref_gray = cv2.cvtColor(ref_original, cv2.COLOR_BGR2GRAY) if len(ref_original.shape) == 3 else ref_original
        ref_gray = cv2.resize(ref_gray, (400, 200))
        
        axes[0, 0].imshow(ref_gray, cmap='gray')
        axes[0, 0].set_title("Reference: Original (Grayscale)")
        axes[0, 0].axis('off')
        
        axes[0, 1].imshow(cv2.GaussianBlur(ref_gray, (5, 5), 0), cmap='gray')
        axes[0, 1].set_title("Reference: After Gaussian Blur")
        axes[0, 1].axis('off')
        
        axes[0, 2].imshow(ref_preprocessed, cmap='gray')
        axes[0, 2].set_title("Reference: Final Binary Image")
        axes[0, 2].axis('off')
        
        # Test signature processing
        test_original = cv2.imread(test_filename)
        test_gray = cv2.cvtColor(test_original, cv2.COLOR_BGR2GRAY) if len(test_original.shape) == 3 else test_original
        test_gray = cv2.resize(test_gray, (400, 200))
        
        axes[1, 0].imshow(test_gray, cmap='gray')
        axes[1, 0].set_title("Test: Original (Grayscale)")
        axes[1, 0].axis('off')
        
        axes[1, 1].imshow(cv2.GaussianBlur(test_gray, (5, 5), 0), cmap='gray')
        axes[1, 1].set_title("Test: After Gaussian Blur")
        axes[1, 1].axis('off')
        
        axes[1, 2].imshow(test_preprocessed, cmap='gray')
        axes[1, 2].set_title("Test: Final Binary Image")
        axes[1, 2].axis('off')
        
        plt.tight_layout()
        plt.show()


# ============================================================================
# Run the main function
# ============================================================================
if __name__ == "__main__":
    main()

