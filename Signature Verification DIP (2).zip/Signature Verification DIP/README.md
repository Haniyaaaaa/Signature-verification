# Signature Verification System using Digital Image Processing

A Python-based signature verification system that uses digital image processing techniques to verify if a signature is genuine or fake by comparing it with a reference signature.

## Features

- **Image Preprocessing**: Automatic grayscale conversion, noise reduction, and binarization
- **Feature Extraction**: Extracts multiple features including:
  - Geometric features (aspect ratio, density, bounding box)
  - Contour analysis (area, perimeter, solidity, extent)
  - Texture features (Local Binary Pattern)
  - Invariant moments (Hu Moments)
  - Projection profiles (horizontal and vertical)
- **Similarity Matching**: Calculates similarity score between reference and test signatures
- **Google Colab Ready**: Complete notebook with file upload interface
- **Visualization**: Displays preprocessing steps and verification results

## Requirements

- Python 3.7+
- OpenCV
- scikit-image
- scipy
- numpy
- matplotlib
- Pillow
- Flask (for web interface)
- flask-cors (for web interface)

## Installation

### For Local Use:

```bash
pip install -r requirements.txt
```

### For Google Colab:

The notebook will automatically install all required packages.

## Usage

### Web Interface (Recommended)

1. **Install dependencies:**
   ```bash
   pip install -r requirements.txt
   ```

2. **Start the Flask backend server:**
   ```bash
   python app.py
   ```
   The server will start on `http://localhost:5000`

3. **Open the web interface:**
   - Open `index.html` in your web browser
   - Or use a local server (e.g., `python -m http.server 8000` and visit `http://localhost:8000`)

4. **Use the interface:**
   - Upload a reference signature (genuine signature)
   - Upload a test signature (signature to verify)
   - Adjust the similarity threshold using the slider
   - Click "Verify Signature" to see the results

### Google Colab (Alternative)

1. Open `Signature_Verification_Colab.ipynb` in Google Colab
2. Upload the `signature_verifier.py` file
3. Follow the step-by-step instructions in the notebook:
   - Install required libraries
   - Upload reference signature
   - Upload test signature to verify
   - View results

### Local Python Script

```python
from signature_verifier import SignatureVerifier

# Initialize verifier with reference signature
verifier = SignatureVerifier('reference_signature.jpg')

# Verify a test signature
result = verifier.verify_signature('test_signature.jpg', threshold=0.75)

# Check results
if result['is_genuine']:
    print("✓ GENUINE SIGNATURE")
else:
    print("✗ FAKE SIGNATURE")

print(f"Similarity Score: {result['similarity_score']:.4f}")
print(f"Confidence: {result['confidence']}")
```

### Compare Two Signatures Directly

```python
from signature_verifier import SignatureVerifier

verifier = SignatureVerifier()

# Compare two signatures
result = verifier.compare_signatures(
    'signature1.jpg',
    'signature2.jpg',
    threshold=0.75
)

print(f"Match: {result['is_match']}")
print(f"Similarity: {result['similarity_score']:.4f}")
```

## How It Works

1. **Preprocessing**:
   - Converts image to grayscale
   - Resizes to standard dimensions (400x200)
   - Applies Gaussian blur for noise reduction
   - Performs adaptive thresholding for binarization
   - Applies morphological operations to clean the image

2. **Feature Extraction**:
   - Extracts geometric features (aspect ratio, density, centroid)
   - Analyzes contours (area, perimeter, solidity)
   - Computes texture features using Local Binary Pattern (LBP)
   - Calculates Hu Moments for shape description
   - Generates horizontal and vertical projection profiles

3. **Similarity Calculation**:
   - Compares extracted features between reference and test signatures
   - Uses weighted similarity scoring
   - Returns a similarity score between 0 and 1

4. **Verification**:
   - Compares similarity score against threshold (default: 0.75)
   - Classifies signature as genuine or fake
   - Provides confidence level (High/Medium/Low)

## Parameters

- **threshold**: Similarity threshold (0.0 to 1.0)
  - Lower values (e.g., 0.65): More lenient, may accept some fake signatures
  - Higher values (e.g., 0.85): More strict, may reject some genuine signatures
  - Default: 0.75

## File Structure

```
Signature Verification DIP/
│
├── signature_verifier.py          # Main verification module
├── app.py                         # Flask backend server
├── app.js                         # Frontend JavaScript
├── index.html                     # Web interface
├── style.css                      # Web interface styles
├── complete_signature_verification.py  # Standalone Colab version
├── example_usage.py               # Example Python usage
├── requirements.txt               # Python dependencies
└── README.md                      # This file
```

## Tips for Best Results

1. **Image Quality**: Use clear, high-resolution signature images
2. **Background**: White or light-colored backgrounds work best
3. **Reference Signature**: Use a high-quality reference signature for better accuracy
4. **Threshold Tuning**: Adjust the threshold based on your specific use case:
   - For strict verification (e.g., legal documents): Use 0.80-0.85
   - For general verification: Use 0.70-0.75
   - For lenient verification: Use 0.65-0.70

## Limitations

- Works best with signatures on white/light backgrounds
- May require threshold adjustment for different signature styles
- Performance depends on image quality and clarity
- Not suitable for very stylized or artistic signatures

## Future Enhancements

- Deep learning-based feature extraction
- Support for multiple reference signatures
- Real-time verification
- Database integration for storing reference signatures
- Advanced forgery detection techniques

## License

This project is open source and available for educational purposes.

## Author

Created for Digital Image Processing project.

## Acknowledgments

- OpenCV for image processing capabilities
- scikit-image for advanced image analysis
- Google Colab for providing a free computational environment

