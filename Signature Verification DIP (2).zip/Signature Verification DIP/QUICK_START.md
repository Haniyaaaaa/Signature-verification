# Quick Start Guide

## Step 1: Install Dependencies

Open a terminal/command prompt in this folder and run:

```bash
pip install -r requirements.txt
```

## Step 2: Start the Flask Server

**Option A: Using the batch file (Windows)**
- Double-click `start_server.bat`

**Option B: Using command line**
```bash
python app.py
```

You should see:
```
Starting Signature Verification Server...
Server will run on http://localhost:5000
 * Running on http://0.0.0.0:5000
```

**Keep this terminal window open!** The server must be running for the web interface to work.

## Step 3: Open the Web Interface

1. Open `index.html` in your web browser
   - You can double-click the file, or
   - Right-click → Open with → Your browser

2. The interface should load and you can:
   - Upload reference signature
   - Upload test signature
   - Click "Verify Signature"

## Troubleshooting

### Error: "Failed to fetch"
- **Solution**: Make sure the Flask server is running (Step 2)
- Check that you see the server messages in the terminal
- Try accessing http://localhost:5000/api/health in your browser - it should return JSON

### Error: "Module not found"
- **Solution**: Run `pip install -r requirements.txt` again
- Make sure you're using Python 3.7 or higher

### Port 5000 already in use
- **Solution**: Close any other applications using port 5000
- Or modify `app.py` to use a different port (change `port=5000` to another number like `port=5001`)
- Then update `app.js` to use the new port in the `API_URL` variable

## Testing the Server

Once the server is running, you can test it by opening:
http://localhost:5000/api/health

You should see:
```json
{"message":"Signature Verification API is running","status":"ok"}
```

