"""Setup script to install and verify dependencies"""
import subprocess
import sys

def check_package(package_name):
    """Check if a package is installed"""
    try:
        __import__(package_name)
        return True
    except ImportError:
        return False

def install_package(package_name):
    """Install a package using pip"""
    print(f"Installing {package_name}...")
    try:
        subprocess.check_call([sys.executable, "-m", "pip", "install", package_name])
        print(f"✓ {package_name} installed successfully")
        return True
    except subprocess.CalledProcessError:
        print(f"✗ Failed to install {package_name}")
        return False

# Required packages
required_packages = {
    'flask': 'flask',
    'flask_cors': 'flask-cors',
    'cv2': 'opencv-python',
    'skimage': 'scikit-image',
    'scipy': 'scipy',
    'numpy': 'numpy',
    'matplotlib': 'matplotlib',
    'PIL': 'Pillow'
}

print("=" * 50)
print("Checking and installing dependencies...")
print("=" * 50)
print()

missing_packages = []
for import_name, package_name in required_packages.items():
    if check_package(import_name):
        print(f"✓ {package_name} is already installed")
    else:
        print(f"✗ {package_name} is missing")
        missing_packages.append(package_name)

if missing_packages:
    print()
    print("Installing missing packages...")
    print("-" * 50)
    failed = []
    for package in missing_packages:
        if not install_package(package):
            failed.append(package)
    
    if failed:
        print()
        print("=" * 50)
        print("ERROR: Failed to install the following packages:")
        for pkg in failed:
            print(f"  - {pkg}")
        print()
        print("Please install manually:")
        print(f"  python -m pip install {' '.join(failed)}")
        print("=" * 50)
        sys.exit(1)
    else:
        print()
        print("=" * 50)
        print("All dependencies installed successfully!")
        print("=" * 50)
else:
    print()
    print("=" * 50)
    print("All dependencies are already installed!")
    print("=" * 50)

print()
print("You can now run the server with: python app.py")
print()

