// Signature Verification System - Main Application Logic

document.addEventListener('DOMContentLoaded', function() {
    // Get DOM elements
    const refUploadArea = document.getElementById('refUploadArea');
    const refImageInput = document.getElementById('refImageInput');
    const refImagePreview = document.getElementById('refImagePreview');
    
    const testUploadArea = document.getElementById('testUploadArea');
    const testImageInput = document.getElementById('testImageInput');
    const testImagePreview = document.getElementById('testImagePreview');
    
    const verifyBtn = document.getElementById('verifyBtn');
    const thresholdSlider = document.getElementById('thresholdSlider');
    const thresholdValue = document.getElementById('thresholdValue');
    
    // Results section elements
    const resultsSection = document.getElementById('resultsSection');
    const loadingSpinner = document.getElementById('loadingSpinner');
    const resultIcon = document.getElementById('resultIcon');
    const resultText = document.getElementById('resultText');
    const resultHeader = document.getElementById('resultHeader');
    const similarityScore = document.getElementById('similarityScore');
    const confidenceLevel = document.getElementById('confidenceLevel');
    const similarityBar = document.getElementById('similarityBar');
    const similarityPercent = document.getElementById('similarityPercent');
    const thresholdDisplay = document.getElementById('thresholdDisplay');
    const refDisplayImage = document.getElementById('refDisplayImage');
    const testDisplayImage = document.getElementById('testDisplayImage');
    const tableSimilarity = document.getElementById('tableSimilarity');
    const tableThreshold = document.getElementById('tableThreshold');
    const tableStatus = document.getElementById('tableStatus');
    const tableConfidence = document.getElementById('tableConfidence');
    
    // API endpoint
    const API_URL = 'http://localhost:5000/api/verify';
    const HEALTH_URL = 'http://localhost:5000/api/health';

    // Check server health on page load
    async function checkServerHealth() {
        try {
            const response = await fetch(HEALTH_URL);
            if (response.ok) {
                console.log('✓ Server is running');
                return true;
            }
        } catch (error) {
            console.warn('⚠ Server is not running:', error.message);
            return false;
        }
        return false;
    }

    // Check server on load
    checkServerHealth().then(isRunning => {
        if (!isRunning) {
            console.warn('Flask server is not running. Please start it with: python app.py');
        }
    });

    // Reference Signature Upload Handlers
    refUploadArea.addEventListener('click', () => {
        refImageInput.click();
    });

    refImageInput.addEventListener('change', (e) => {
        handleImageSelect(e.target.files[0], refImagePreview, refUploadArea, 'ref');
    });

    // Test Signature Upload Handlers
    testUploadArea.addEventListener('click', () => {
        testImageInput.click();
    });

    testImageInput.addEventListener('change', (e) => {
        handleImageSelect(e.target.files[0], testImagePreview, testUploadArea, 'test');
    });

    // Drag and Drop Handlers for Reference Signature
    refUploadArea.addEventListener('dragover', (e) => {
        e.preventDefault();
        refUploadArea.classList.add('dragover');
    });

    refUploadArea.addEventListener('dragleave', () => {
        refUploadArea.classList.remove('dragover');
    });

    refUploadArea.addEventListener('drop', (e) => {
        e.preventDefault();
        refUploadArea.classList.remove('dragover');
        const file = e.dataTransfer.files[0];
        if (file && file.type.startsWith('image/')) {
            handleImageSelect(file, refImagePreview, refUploadArea, 'ref');
        }
    });

    // Drag and Drop Handlers for Test Signature
    testUploadArea.addEventListener('dragover', (e) => {
        e.preventDefault();
        testUploadArea.classList.add('dragover');
    });

    testUploadArea.addEventListener('dragleave', () => {
        testUploadArea.classList.remove('dragover');
    });

    testUploadArea.addEventListener('drop', (e) => {
        e.preventDefault();
        testUploadArea.classList.remove('dragover');
        const file = e.dataTransfer.files[0];
        if (file && file.type.startsWith('image/')) {
            handleImageSelect(file, testImagePreview, testUploadArea, 'test');
        }
    });

    // Handle image selection and preview
    function handleImageSelect(file, previewElement, uploadArea, type) {
        if (!file || !file.type.startsWith('image/')) {
            alert('Please select a valid image file.');
            return;
        }

        const reader = new FileReader();
        reader.onload = (e) => {
            previewElement.src = e.target.result;
            previewElement.classList.remove('d-none');
            uploadArea.classList.add('has-image');
            
            // Store the image data for verification
            if (type === 'ref') {
                window.refImageData = e.target.result;
            } else {
                window.testImageData = e.target.result;
            }
            
            // Enable verify button if both images are selected
            checkVerifyButton();
        };
        reader.readAsDataURL(file);
    }

    // Check if verify button should be enabled
    function checkVerifyButton() {
        if (window.refImageData && window.testImageData) {
            verifyBtn.disabled = false;
        } else {
            verifyBtn.disabled = true;
        }
    }

    // Threshold slider handler
    thresholdSlider.addEventListener('input', (e) => {
        thresholdValue.textContent = e.target.value;
    });

    // Verify button handler
    verifyBtn.addEventListener('click', async () => {
        if (!window.refImageData || !window.testImageData) {
            alert('Please upload both reference and test signatures.');
            return;
        }
        
        // Show loading spinner and hide results
        loadingSpinner.classList.remove('d-none');
        resultsSection.classList.add('d-none');
        verifyBtn.disabled = true;
        
        try {
            const threshold = parseFloat(thresholdSlider.value);
            
            // Send verification request to backend
            const response = await fetch(API_URL, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify({
                    reference_image: window.refImageData,
                    test_image: window.testImageData,
                    threshold: threshold
                })
            });
            
            const result = await response.json();
            
            if (!response.ok) {
                throw new Error(result.error || 'Verification failed');
            }
            
            // Display results
            displayResults(result);
            
        } catch (error) {
            console.error('Verification error:', error);
            let errorMessage = 'Error during verification: ' + error.message;
            
            // Check if it's a network/fetch error
            if (error.message === 'Failed to fetch' || error.name === 'TypeError') {
                errorMessage = 'Failed to connect to the server.\n\n' +
                    'Please make sure:\n' +
                    '1. The Flask server is running (run: python app.py)\n' +
                    '2. The server is accessible at http://localhost:5000\n' +
                    '3. No firewall is blocking the connection';
            }
            
            alert(errorMessage);
        } finally {
            // Hide loading spinner
            loadingSpinner.classList.add('d-none');
            verifyBtn.disabled = false;
        }
    });
    
    // Display verification results
    function displayResults(result) {
        const isGenuine = result.is_genuine;
        const similarity = result.similarity_score;
        const similarityPercentValue = result.similarity_percent;
        const threshold = result.threshold;
        const confidence = result.confidence;
        
        // Update result icon and text
        if (isGenuine) {
            resultIcon.className = 'bi bi-check-circle-fill result-genuine';
            resultText.textContent = 'GENUINE SIGNATURE';
            resultText.className = 'fw-bold result-genuine';
            resultHeader.className = 'card-header bg-success text-white';
        } else {
            resultIcon.className = 'bi bi-x-circle-fill result-fake';
            resultText.textContent = 'FAKE SIGNATURE';
            resultText.className = 'fw-bold result-fake';
            resultHeader.className = 'card-header bg-danger text-white';
        }
        
        // Update similarity score
        similarityScore.textContent = similarityPercentValue.toFixed(2) + '%';
        
        // Update confidence level
        confidenceLevel.textContent = confidence;
        confidenceLevel.className = 'fw-bold ' + 
            (confidence === 'High' ? 'confidence-high' : 
             confidence === 'Medium' ? 'confidence-medium' : 'confidence-low');
        
        // Update progress bar
        const barWidth = similarityPercentValue;
        similarityBar.style.width = barWidth + '%';
        similarityBar.className = 'progress-bar progress-bar-striped progress-bar-animated ' +
            (isGenuine ? 'bg-success' : 'bg-danger');
        similarityPercent.textContent = barWidth.toFixed(2) + '%';
        
        // Update threshold display
        thresholdDisplay.textContent = (threshold * 100).toFixed(0) + '%';
        
        // Update display images
        refDisplayImage.src = window.refImageData;
        testDisplayImage.src = window.testImageData;
        
        // Update table
        tableSimilarity.textContent = similarityPercentValue.toFixed(2) + '%';
        tableThreshold.textContent = (threshold * 100).toFixed(0) + '%';
        tableStatus.innerHTML = isGenuine ? 
            '<span class="badge bg-success">GENUINE</span>' : 
            '<span class="badge bg-danger">FAKE</span>';
        tableConfidence.innerHTML = 
            '<span class="badge ' + 
            (confidence === 'High' ? 'bg-success' : 
             confidence === 'Medium' ? 'bg-warning' : 'bg-danger') + 
            '">' + confidence + '</span>';
        
        // Show results section
        resultsSection.classList.remove('d-none');
        
        // Scroll to results
        resultsSection.scrollIntoView({ behavior: 'smooth', block: 'start' });
    }

    // Initialize
    window.refImageData = null;
    window.testImageData = null;
});

