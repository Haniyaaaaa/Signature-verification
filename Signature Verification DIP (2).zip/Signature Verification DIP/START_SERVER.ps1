# PowerShell script to start the Flask server
Write-Host "========================================" -ForegroundColor Cyan
Write-Host "Signature Verification Server" -ForegroundColor Cyan
Write-Host "========================================" -ForegroundColor Cyan
Write-Host ""
Write-Host "Starting Flask server..." -ForegroundColor Yellow
Write-Host "Server will be available at: http://localhost:5000" -ForegroundColor Green
Write-Host ""
Write-Host "IMPORTANT: Keep this window open while using the website!" -ForegroundColor Red
Write-Host "Press Ctrl+C to stop the server." -ForegroundColor Yellow
Write-Host ""
Write-Host "After the server starts, open index.html in your browser." -ForegroundColor Cyan
Write-Host ""

python app.py

