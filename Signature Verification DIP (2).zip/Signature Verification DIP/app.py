"""
Flask Backend Server for Signature Verification System
This server handles image uploads and signature verification using DIP
"""

from flask import Flask, request, jsonify
from flask_cors import CORS
import cv2
import numpy as np
from signature_verifier import SignatureVerifier
import base64
import io
from PIL import Image

app = Flask(__name__)
CORS(app)  # Enable CORS for frontend requests

def base64_to_image(base64_string):
    """Convert base64 string to OpenCV image"""
    try:
        # Remove data URL prefix if present
        if ',' in base64_string:
            base64_string = base64_string.split(',')[1]
        
        # Decode base64
        image_data = base64.b64decode(base64_string)
        
        # Convert to PIL Image
        pil_image = Image.open(io.BytesIO(image_data))
        
        # Convert to RGB if necessary
        if pil_image.mode != 'RGB':
            pil_image = pil_image.convert('RGB')
        
        # Convert to numpy array
        img_array = np.array(pil_image)
        
        # Convert RGB to BGR for OpenCV
        img_bgr = cv2.cvtColor(img_array, cv2.COLOR_RGB2BGR)
        
        return img_bgr
    except Exception as e:
        raise ValueError(f"Error decoding image: {str(e)}")

@app.route('/api/verify', methods=['POST'])
def verify_signature():
    """Verify signature endpoint"""
    try:
        data = request.json
        
        if not data:
            return jsonify({'error': 'No data provided'}), 400
        
        ref_image_base64 = data.get('reference_image')
        test_image_base64 = data.get('test_image')
        threshold = float(data.get('threshold', 0.75))
        
        if not ref_image_base64 or not test_image_base64:
            return jsonify({'error': 'Both reference and test images are required'}), 400
        
        # Convert base64 to OpenCV images
        ref_image = base64_to_image(ref_image_base64)
        test_image = base64_to_image(test_image_base64)
        
        # Initialize verifier with reference signature
        verifier = SignatureVerifier()
        verifier.load_reference_signature(ref_image)
        
        # Verify the test signature
        result = verifier.verify_signature(test_image, threshold=threshold)
        
        # Format response - convert numpy types to Python native types for JSON serialization
        response = {
            'success': True,
            'is_genuine': bool(result['is_genuine']),  # Ensure it's a Python bool, not numpy bool
            'similarity_score': float(round(result['similarity_score'], 4)),
            'similarity_percent': float(round(result['similarity_score'] * 100, 2)),
            'threshold': float(threshold),
            'confidence': str(result['confidence'])  # Ensure it's a string
        }
        
        return jsonify(response)
    
    except ValueError as e:
        return jsonify({'error': str(e)}), 400
    except Exception as e:
        return jsonify({'error': f'Server error: {str(e)}'}), 500

@app.route('/api/health', methods=['GET'])
def health_check():
    """Health check endpoint"""
    return jsonify({'status': 'ok', 'message': 'Signature Verification API is running'})

if __name__ == '__main__':
    print("Starting Signature Verification Server...")
    print("Server will run on http://localhost:5000")
    app.run(debug=True, host='0.0.0.0', port=5000)

