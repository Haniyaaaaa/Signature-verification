"""Test script to check if all required packages can be imported"""
import sys

packages_to_test = {
    'flask': 'flask',
    'flask_cors': 'flask_cors', 
    'cv2': 'cv2',
    'numpy': 'numpy',
    'scipy': 'scipy',
    'matplotlib': 'matplotlib',
    'PIL': 'PIL',
    'skimage': 'skimage'
}

print("Testing package imports...")
print("=" * 50)

all_ok = True
for import_name, display_name in packages_to_test.items():
    try:
        __import__(import_name)
        print(f"✓ {display_name:20s} - OK")
    except ImportError as e:
        print(f"✗ {display_name:20s} - MISSING")
        all_ok = False

print("=" * 50)
if all_ok:
    print("All packages are installed!")
    sys.exit(0)
else:
    print("Some packages are missing. Please install them.")
    sys.exit(1)

