"""
Example usage of the Signature Verification System
This script demonstrates how to use the SignatureVerifier class locally.
"""

from signature_verifier import SignatureVerifier
import cv2
import matplotlib.pyplot as plt

def main():
    print("="*60)
    print("Signature Verification System - Example Usage")
    print("="*60)
    
    # Example 1: Verify signature with reference
    print("\nExample 1: Verify signature with reference")
    print("-"*60)
    
    # Initialize verifier with reference signature
    # Replace 'reference_signature.jpg' with your reference image path
    reference_path = input("Enter path to reference signature image: ").strip()
    
    try:
        verifier = SignatureVerifier(reference_path)
        print(f"✓ Reference signature loaded: {reference_path}")
        
        # Get test signature path
        test_path = input("Enter path to test signature image: ").strip()
        
        # Verify the signature
        threshold = 0.75
        result = verifier.verify_signature(test_path, threshold=threshold)
        
        # Display results
        print("\n" + "="*60)
        print("VERIFICATION RESULTS")
        print("="*60)
        print(f"Similarity Score: {result['similarity_score']:.4f} ({result['similarity_score']*100:.2f}%)")
        print(f"Threshold: {result['threshold']:.2f}")
        print(f"Confidence: {result['confidence']}")
        print(f"\n{'✓ GENUINE SIGNATURE' if result['is_genuine'] else '✗ FAKE SIGNATURE'}")
        print("="*60)
        
        # Display images
        ref_img = cv2.imread(reference_path)
        test_img = cv2.imread(test_path)
        
        ref_img_rgb = cv2.cvtColor(ref_img, cv2.COLOR_BGR2RGB)
        test_img_rgb = cv2.cvtColor(test_img, cv2.COLOR_BGR2RGB)
        
        fig, axes = plt.subplots(1, 2, figsize=(16, 6))
        axes[0].imshow(ref_img_rgb)
        axes[0].set_title("Reference Signature", fontsize=14, fontweight='bold')
        axes[0].axis('off')
        
        axes[1].imshow(test_img_rgb)
        axes[1].set_title("Test Signature", fontsize=14, fontweight='bold')
        axes[1].axis('off')
        
        plt.tight_layout()
        plt.show()
        
    except FileNotFoundError as e:
        print(f"Error: File not found - {e}")
    except Exception as e:
        print(f"Error: {e}")
    
    # Example 2: Compare two signatures directly
    print("\n\nExample 2: Compare two signatures directly")
    print("-"*60)
    
    try:
        verifier = SignatureVerifier()
        img1_path = input("Enter path to first signature image: ").strip()
        img2_path = input("Enter path to second signature image: ").strip()
        
        result = verifier.compare_signatures(img1_path, img2_path, threshold=0.75)
        
        print("\n" + "="*60)
        print("COMPARISON RESULTS")
        print("="*60)
        print(f"Match: {'✓ YES' if result['is_match'] else '✗ NO'}")
        print(f"Similarity Score: {result['similarity_score']:.4f} ({result['similarity_score']*100:.2f}%)")
        print(f"Confidence: {result['confidence']}")
        print("="*60)
        
    except Exception as e:
        print(f"Error: {e}")

if __name__ == "__main__":
    main()

